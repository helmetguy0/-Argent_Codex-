// Stub module loaded successfully.
console.log('Module loaded:', document.currentScript.src);